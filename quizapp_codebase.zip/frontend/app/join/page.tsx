'use client';
import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { api, getUser } from '../lib/socket';

export default function JoinPage() {
  const router = useRouter();
  const user = getUser();
  const [code, setCode] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [room, setRoom] = useState<any>(null);

  const handleLookup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (code.trim().length !== 6) { setError('Room code must be 6 characters'); return; }
    setError(''); setLoading(true);
    try {
      const session = await api.get(`/api/sessions/room/${code.toUpperCase()}`);
      setRoom(session);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleJoin = () => {
    if (!user) { router.push(`/auth/login?next=/join`); return; }
    router.push(`/play/${code.toUpperCase()}`);
  };

  return (
    <div style={{
      minHeight: '100vh', display: 'flex', flexDirection: 'column',
      alignItems: 'center', justifyContent: 'center', padding: '2rem',
      background: 'radial-gradient(ellipse at 50% 40%, rgba(0,229,255,0.07) 0%, transparent 65%), var(--bg-primary)',
    }}>
      <Link href="/" style={{ marginBottom: '2.5rem' }}>
        <span style={{ fontFamily: 'Barlow Condensed', fontSize: '2rem', fontWeight: 800, color: 'var(--accent-yellow)' }}>⚡ QUIZAPP</span>
      </Link>

      <div style={{ width: '100%', maxWidth: 460 }}>
        <div className="card" style={{ padding: '2.5rem', textAlign: 'center' }}>
          <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>🎮</div>
          <h1 style={{ fontFamily: 'Barlow Condensed', fontSize: '2.2rem', marginBottom: '0.4rem' }}>Join a Quiz</h1>
          <p style={{ color: 'var(--text-secondary)', marginBottom: '2rem', fontSize: '0.95rem' }}>
            Enter the 6-character room code from your host
          </p>

          {error && (
            <div style={{
              background: 'rgba(255,61,139,0.1)', border: '1px solid rgba(255,61,139,0.3)',
              borderRadius: 'var(--radius)', padding: '0.75rem', marginBottom: '1rem',
              color: 'var(--accent-pink)', fontSize: '0.9rem',
            }}>{error}</div>
          )}

          {!room ? (
            <form onSubmit={handleLookup}>
              <input
                value={code}
                onChange={(e) => setCode(e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 6))}
                placeholder="ABC123"
                maxLength={6}
                style={{
                  textAlign: 'center', fontSize: '2.2rem', fontFamily: 'Barlow Condensed',
                  letterSpacing: '0.3em', fontWeight: 700, padding: '1rem',
                  marginBottom: '1.25rem',
                }}
              />
              <button className="btn-cyan" type="submit" disabled={loading}
                style={{ width: '100%', fontSize: '1rem', padding: '0.9rem', opacity: loading ? 0.7 : 1 }}>
                {loading ? 'Looking up...' : 'Find Room →'}
              </button>
            </form>
          ) : (
            <div style={{ animation: 'fadeIn 0.3s ease' }}>
              <div style={{
                background: 'rgba(0,230,118,0.08)', border: '1px solid rgba(0,230,118,0.2)',
                borderRadius: 'var(--radius)', padding: '1.25rem', marginBottom: '1.5rem', textAlign: 'left',
              }}>
                <div style={{ color: 'var(--text-secondary)', fontSize: '0.8rem', marginBottom: '0.25rem' }}>QUIZ FOUND</div>
                <div style={{ fontFamily: 'Barlow Condensed', fontSize: '1.5rem', fontWeight: 700 }}>
                  {room.quiz?.title}
                </div>
                <div style={{ color: 'var(--text-secondary)', fontSize: '0.85rem', marginTop: '0.3rem' }}>
                  {room.quiz?.category} · {room._count?.participants || 0} players waiting
                </div>
              </div>

              {user ? (
                <button className="btn-primary" onClick={handleJoin}
                  style={{ width: '100%', fontSize: '1rem', padding: '0.9rem' }}>
                  Join as {user.name} →
                </button>
              ) : (
                <div>
                  <p style={{ color: 'var(--text-secondary)', fontSize: '0.9rem', marginBottom: '1rem' }}>
                    You need to be logged in to join
                  </p>
                  <Link href={`/auth/login?next=/play/${code}`}>
                    <button className="btn-primary" style={{ width: '100%', padding: '0.9rem' }}>
                      Log In to Join →
                    </button>
                  </Link>
                </div>
              )}

              <button className="btn-secondary" onClick={() => setRoom(null)}
                style={{ width: '100%', marginTop: '0.75rem', padding: '0.7rem' }}>
                Try Different Code
              </button>
            </div>
          )}
        </div>

        <p style={{ textAlign: 'center', marginTop: '1.5rem', color: 'var(--text-muted)', fontSize: '0.85rem' }}>
          Want to host?{' '}
          <Link href="/auth/register?role=ORGANIZER" style={{ color: 'var(--accent-cyan)' }}>Create an organizer account</Link>
        </p>
      </div>
    </div>
  );
}
