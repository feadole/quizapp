'use client';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import { getUser } from '../lib/socket';

export default function HomePage() {
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    setUser(getUser());
  }, []);

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg-primary)' }}>
      {/* Navbar */}
      <nav style={{
        borderBottom: '1px solid var(--border)',
        padding: '1rem 0',
        position: 'sticky', top: 0, zIndex: 100,
        background: 'rgba(10,10,18,0.85)',
        backdropFilter: 'blur(12px)',
      }}>
        <div className="container" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span style={{ fontFamily: 'Barlow Condensed', fontSize: '1.6rem', fontWeight: 800, color: 'var(--accent-yellow)' }}>
            ⚡ QUIZAPP
          </span>
          <div style={{ display: 'flex', gap: '0.75rem' }}>
            {user ? (
              <Link href="/dashboard"><button className="btn-primary">Dashboard</button></Link>
            ) : (
              <>
                <Link href="/auth/login"><button className="btn-secondary">Log In</button></Link>
                <Link href="/auth/register"><button className="btn-primary">Sign Up</button></Link>
              </>
            )}
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section style={{ padding: '6rem 1.5rem 4rem', textAlign: 'center' }}>
        <div style={{
          display: 'inline-block',
          background: 'rgba(245,230,66,0.12)',
          color: 'var(--accent-yellow)',
          padding: '0.3rem 1rem',
          borderRadius: '100px',
          fontSize: '0.85rem',
          fontWeight: 600,
          marginBottom: '1.5rem',
          letterSpacing: '0.08em',
          textTransform: 'uppercase',
        }}>Real-Time Quiz Platform</div>

        <h1 style={{
          fontFamily: 'Barlow Condensed',
          fontSize: 'clamp(3rem, 8vw, 6rem)',
          fontWeight: 800,
          lineHeight: 1.05,
          marginBottom: '1.5rem',
          letterSpacing: '-0.01em',
        }}>
          Engage Your Audience<br />
          <span style={{ color: 'var(--accent-cyan)' }}>Live.</span>
        </h1>

        <p style={{ color: 'var(--text-secondary)', fontSize: '1.15rem', maxWidth: 540, margin: '0 auto 2.5rem' }}>
          Build interactive quizzes, launch them in seconds, and watch your audience compete in real time on any device.
        </p>

        <div style={{ display: 'flex', gap: '1rem', justifyContent: 'center', flexWrap: 'wrap' }}>
          <Link href="/auth/register?role=ORGANIZER">
            <button className="btn-primary" style={{ fontSize: '1rem', padding: '1rem 2.5rem' }}>
              Create a Quiz →
            </button>
          </Link>
          <Link href="/join">
            <button className="btn-secondary" style={{ fontSize: '1rem', padding: '1rem 2.5rem' }}>
              Join with Code
            </button>
          </Link>
        </div>
      </section>

      {/* Features */}
      <section style={{ padding: '4rem 1.5rem', background: 'var(--bg-secondary)' }}>
        <div className="container">
          <h2 style={{ textAlign: 'center', fontSize: '2.5rem', marginBottom: '3rem', fontFamily: 'Barlow Condensed' }}>
            Everything you need
          </h2>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: '1.5rem' }}>
            {features.map((f) => (
              <div key={f.title} className="card fade-in" style={{ padding: '1.8rem' }}>
                <div style={{ fontSize: '2rem', marginBottom: '1rem' }}>{f.icon}</div>
                <h3 style={{ fontFamily: 'Barlow Condensed', fontSize: '1.3rem', marginBottom: '0.5rem' }}>{f.title}</h3>
                <p style={{ color: 'var(--text-secondary)', fontSize: '0.9rem' }}>{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer style={{ padding: '2rem', textAlign: 'center', color: 'var(--text-muted)', fontSize: '0.85rem' }}>
        © 2025 QuizApp — Built with Next.js, Socket.IO & PostgreSQL
      </footer>
    </div>
  );
}

const features = [
  { icon: '🎮', title: 'Real-Time Gameplay', desc: 'Questions appear simultaneously for all players — every millisecond counts.' },
  { icon: '🖼️', title: 'Rich Question Types', desc: 'Text, images, single choice, multiple choice. Build any kind of quiz.' },
  { icon: '🏆', title: 'Live Leaderboard', desc: 'Dynamic scoring with time bonuses. The faster you answer, the more you earn.' },
  { icon: '🔗', title: 'Instant Join', desc: 'Participants join via 6-character room code. No signup needed to play.' },
  { icon: '📊', title: 'Analytics Dashboard', desc: 'Track your quiz history, participation rates, and scores over time.' },
  { icon: '🌐', title: '18 Languages', desc: 'Accessible to a global audience — fully localized interface.' },
];
