'use client';
import { useEffect, useState, useRef } from 'react';
import Link from 'next/link';
import { useParams, useRouter } from 'next/navigation';
import { api, getUser, getSocket } from '../../../lib/socket';

type Phase = 'connecting' | 'lobby' | 'question' | 'answered' | 'between' | 'finished';

const OPTION_COLORS = [
  { bg: 'rgba(245,230,66,0.15)', border: 'rgba(245,230,66,0.4)', active: 'rgba(245,230,66,0.35)' },
  { bg: 'rgba(0,229,255,0.1)',   border: 'rgba(0,229,255,0.35)',  active: 'rgba(0,229,255,0.3)'  },
  { bg: 'rgba(255,61,139,0.1)',  border: 'rgba(255,61,139,0.3)',  active: 'rgba(255,61,139,0.28)'},
  { bg: 'rgba(0,230,118,0.1)',   border: 'rgba(0,230,118,0.3)',   active: 'rgba(0,230,118,0.28)' },
];

export default function PlayPage() {
  const { roomCode } = useParams<{ roomCode: string }>();
  const router = useRouter();
  const user = getUser();

  const [phase, setPhase] = useState<Phase>('connecting');
  const [sessionId, setSessionId] = useState('');
  const [participantId, setParticipantId] = useState('');
  const [quizTitle, setQuizTitle] = useState('');
  const [participants, setParticipants] = useState<any[]>([]);
  const [question, setQuestion] = useState<any>(null);
  const [questionIndex, setQuestionIndex] = useState(0);
  const [timeLeft, setTimeLeft] = useState(0);
  const [selected, setSelected] = useState<string[]>([]);
  const [answerResult, setAnswerResult] = useState<{ isCorrect: boolean; pointsEarned: number } | null>(null);
  const [correctOptions, setCorrectOptions] = useState<any[]>([]);
  const [myScore, setMyScore] = useState(0);
  const [leaderboard, setLeaderboard] = useState<any[]>([]);
  const [myRank, setMyRank] = useState<number | null>(null);
  const [error, setError] = useState('');
  const [answerProgress, setAnswerProgress] = useState({ answered: 0, total: 0 });
  const questionStartRef = useRef<number>(0);

  useEffect(() => {
    if (!user) { router.push(`/auth/login?next=/play/${roomCode}`); return; }

    const socket = getSocket();
    socket.connect();
    socket.emit('join_room', { roomCode, userId: user.id });

    socket.on('room_joined', async ({ sessionId: sid, quizTitle: title, participants: pp, status }: any) => {
      setSessionId(sid);
      setQuizTitle(title);
      setParticipants(pp);
      // Find our participantId
      try {
        const hist = await api.get('/api/sessions/history/me');
        const s = hist.find((h: any) => h.id === sid);
        if (s?.participantId) setParticipantId(s.participantId);
      } catch {}
      if (status === 'ACTIVE') {
        // Reconnect mid-game — wait for next question event
        setPhase('lobby');
      } else {
        setPhase('lobby');
      }
    });

    socket.on('participant_joined', ({ participants: pp }: any) => setParticipants(pp));

    socket.on('quiz_started', ({ question: q, questionIndex: qi }: any) => {
      setQuestion(q); setQuestionIndex(qi); setSelected([]);
      setAnswerResult(null); setCorrectOptions([]);
      setAnswerProgress({ answered: 0, total: participants.length });
      questionStartRef.current = Date.now();
      setPhase('question');
    });

    socket.on('question_shown', ({ question: q, questionIndex: qi }: any) => {
      setQuestion(q); setQuestionIndex(qi); setSelected([]);
      setAnswerResult(null); setCorrectOptions([]);
      questionStartRef.current = Date.now();
      setPhase('question');
    });

    socket.on('timer_tick', ({ timeLeft: t }: any) => setTimeLeft(t));

    socket.on('answer_result', ({ isCorrect, pointsEarned }: any) => {
      setAnswerResult({ isCorrect, pointsEarned });
      setMyScore((prev) => prev + pointsEarned);
      setPhase('answered');
    });

    socket.on('already_answered', () => setPhase('answered'));

    socket.on('answer_progress', ({ answered, total }: any) =>
      setAnswerProgress({ answered, total }));

    socket.on('question_ended', ({ correctOptions: co, leaderboard: lb }: any) => {
      setCorrectOptions(co); setLeaderboard(lb);
      const rank = lb.findIndex((p: any) => p.userId === user.id) + 1;
      setMyRank(rank || null);
      setPhase('between');
    });

    socket.on('quiz_ended', ({ leaderboard: lb }: any) => {
      setLeaderboard(lb);
      const entry = lb.find((p: any) => p.userId === user.id);
      if (entry) { setMyRank(entry.rank); setMyScore(entry.score); }
      setPhase('finished');
    });

    socket.on('error', ({ message }: any) => setError(message));

    return () => { socket.off(); socket.disconnect(); };
  }, [roomCode]);

  const handleSelect = (optId: string) => {
    if (phase !== 'question') return;
    if (question.type === 'SINGLE') {
      setSelected([optId]);
    } else {
      setSelected((prev) =>
        prev.includes(optId) ? prev.filter((id) => id !== optId) : [...prev, optId]
      );
    }
  };

  const handleSubmit = () => {
    if (!selected.length || phase !== 'question') return;
    getSocket().emit('submit_answer', {
      participantId,
      questionId: question.id,
      selectedOptions: selected,
      sessionId,
      questionIndex,
    });
  };

  // Auto-submit for SINGLE after selecting
  useEffect(() => {
    if (question?.type === 'SINGLE' && selected.length === 1 && phase === 'question') {
      handleSubmit();
    }
  }, [selected]);

  if (error) return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', background: 'var(--bg-primary)', padding: '2rem', textAlign: 'center' }}>
      <div style={{ fontSize: '2.5rem', marginBottom: '1rem' }}>⚠️</div>
      <div style={{ color: 'var(--accent-pink)', fontSize: '1.1rem', marginBottom: '1.5rem' }}>{error}</div>
      <Link href="/join"><button className="btn-secondary">Try Again</button></Link>
    </div>
  );

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg-primary)', display: 'flex', flexDirection: 'column' }}>
      {/* Top bar */}
      <div style={{
        background: 'var(--bg-secondary)', borderBottom: '1px solid var(--border)',
        padding: '0.75rem 1.5rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center',
      }}>
        <span style={{ fontFamily: 'Barlow Condensed', fontSize: '1.3rem', fontWeight: 700, color: 'var(--accent-yellow)' }}>
          ⚡ {quizTitle || 'QuizApp'}
        </span>
        <div style={{ display: 'flex', gap: '1rem', alignItems: 'center' }}>
          {phase !== 'lobby' && phase !== 'connecting' && (
            <span style={{ fontFamily: 'Barlow Condensed', fontSize: '1.2rem', color: 'var(--accent-cyan)' }}>
              {myScore} pts
            </span>
          )}
          <span style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>{user?.name}</span>
        </div>
      </div>

      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '1.5rem' }}>

        {/* CONNECTING */}
        {phase === 'connecting' && (
          <div style={{ textAlign: 'center', color: 'var(--text-secondary)', animation: 'pulse 1.5s ease infinite' }}>
            Connecting to room <strong style={{ color: 'var(--accent-yellow)' }}>{roomCode}</strong>…
          </div>
        )}

        {/* LOBBY */}
        {phase === 'lobby' && (
          <div style={{ textAlign: 'center', maxWidth: 420 }}>
            <div style={{ fontSize: '3rem', marginBottom: '1.5rem' }}>🎮</div>
            <h1 style={{ fontFamily: 'Barlow Condensed', fontSize: '2rem', marginBottom: '0.5rem' }}>You're in!</h1>
            <div style={{ fontFamily: 'Barlow Condensed', fontSize: '3.5rem', fontWeight: 800,
              color: 'var(--accent-yellow)', letterSpacing: '0.2em', marginBottom: '1rem' }}>
              {roomCode}
            </div>
            <p style={{ color: 'var(--text-secondary)', marginBottom: '2rem' }}>
              Waiting for the host to start…<br />
              <span style={{ color: 'var(--accent-cyan)' }}>{participants.length}</span> player{participants.length !== 1 ? 's' : ''} in lobby
            </p>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem', justifyContent: 'center' }}>
              {participants.map((p) => (
                <span key={p.userId} className="badge badge-cyan"
                  style={{ background: p.userId === user?.id ? 'rgba(245,230,66,0.15)' : undefined,
                    color: p.userId === user?.id ? 'var(--accent-yellow)' : undefined }}>
                  {p.name} {p.userId === user?.id && '(you)'}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* QUESTION */}
        {(phase === 'question' || phase === 'answered') && question && (
          <div style={{ width: '100%', maxWidth: 700 }}>
            {/* Timer + progress */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.25rem' }}>
              <span style={{ color: 'var(--text-secondary)', fontSize: '0.9rem' }}>
                Q{questionIndex + 1} of {question.totalQuestions}
              </span>
              <div style={{
                fontFamily: 'Barlow Condensed', fontSize: '2.5rem', fontWeight: 800,
                color: timeLeft <= 5 ? 'var(--accent-pink)' : 'var(--text-primary)',
                animation: timeLeft <= 5 ? 'pulse 0.5s ease infinite' : 'none',
              }}>{timeLeft}s</div>
              <span style={{ color: 'var(--text-secondary)', fontSize: '0.85rem' }}>
                {answerProgress.answered}/{answerProgress.total}
              </span>
            </div>

            {/* Timer bar */}
            <div style={{ height: 4, background: 'var(--bg-card)', borderRadius: 2, overflow: 'hidden', marginBottom: '1.5rem' }}>
              <div style={{
                height: '100%', borderRadius: 2, transition: 'width 1s linear, background 1s',
                width: `${(timeLeft / (question.timeLimit || 30)) * 100}%`,
                background: timeLeft <= 5 ? 'var(--accent-pink)' : 'var(--accent-cyan)',
              }} />
            </div>

            {/* Question card */}
            <div className="card" style={{ padding: '1.75rem', marginBottom: '1.25rem', textAlign: 'center' }}>
              {question.imageUrl && (
                <img src={question.imageUrl} alt="" style={{ maxHeight: 180, borderRadius: 'var(--radius)', objectFit: 'contain', marginBottom: '1rem' }} />
              )}
              <h2 style={{ fontFamily: 'Barlow Condensed', fontSize: 'clamp(1.3rem, 3vw, 2rem)' }}>
                {question.text}
              </h2>
              {question.type === 'MULTIPLE' && (
                <p style={{ color: 'var(--text-secondary)', fontSize: '0.8rem', marginTop: '0.5rem' }}>
                  Select all correct answers
                </p>
              )}
            </div>

            {/* Answer options */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem', marginBottom: '1rem' }}>
              {question.options?.map((opt: any, i: number) => {
                const colors = OPTION_COLORS[i % 4];
                const isSelected = selected.includes(opt.id);
                return (
                  <button key={opt.id}
                    onClick={() => handleSelect(opt.id)}
                    disabled={phase === 'answered'}
                    style={{
                      padding: '1.1rem',
                      borderRadius: 'var(--radius)',
                      border: `2px solid ${isSelected ? colors.border : 'transparent'}`,
                      background: isSelected ? colors.active : colors.bg,
                      color: 'var(--text-primary)', fontWeight: 600, fontSize: '0.95rem',
                      textAlign: 'left', transition: 'all 0.15s', cursor: phase === 'answered' ? 'default' : 'pointer',
                      opacity: phase === 'answered' && !isSelected ? 0.55 : 1,
                    }}>
                    {opt.text}
                  </button>
                );
              })}
            </div>

            {/* Submit for MULTIPLE only */}
            {question.type === 'MULTIPLE' && phase === 'question' && (
              <button className="btn-cyan" onClick={handleSubmit}
                disabled={!selected.length}
                style={{ width: '100%', opacity: !selected.length ? 0.5 : 1 }}>
                Submit Answers
              </button>
            )}

            {/* Waiting after answer */}
            {phase === 'answered' && answerResult && (
              <div style={{
                padding: '1rem', borderRadius: 'var(--radius)', textAlign: 'center',
                background: answerResult.isCorrect ? 'rgba(0,230,118,0.1)' : 'rgba(255,61,139,0.1)',
                border: `1px solid ${answerResult.isCorrect ? 'rgba(0,230,118,0.3)' : 'rgba(255,61,139,0.3)'}`,
                animation: 'fadeIn 0.3s ease',
              }}>
                <div style={{ fontSize: '1.5rem', marginBottom: '0.25rem' }}>
                  {answerResult.isCorrect ? '✅' : '❌'}
                </div>
                <div style={{ fontFamily: 'Barlow Condensed', fontSize: '1.4rem', fontWeight: 700,
                  color: answerResult.isCorrect ? 'var(--accent-green)' : 'var(--accent-pink)' }}>
                  {answerResult.isCorrect ? `+${answerResult.pointsEarned} points!` : 'Incorrect'}
                </div>
                <div style={{ color: 'var(--text-secondary)', fontSize: '0.85rem', marginTop: '0.25rem' }}>
                  Waiting for others…
                </div>
              </div>
            )}
          </div>
        )}

        {/* BETWEEN QUESTIONS */}
        {phase === 'between' && (
          <div style={{ textAlign: 'center', maxWidth: 480, width: '100%', animation: 'fadeIn 0.4s ease' }}>
            {answerResult && (
              <div style={{ marginBottom: '1.5rem' }}>
                <div style={{ fontSize: '2.5rem' }}>{answerResult.isCorrect ? '🎯' : '😬'}</div>
                <div style={{ fontFamily: 'Barlow Condensed', fontSize: '2rem',
                  color: answerResult.isCorrect ? 'var(--accent-green)' : 'var(--accent-pink)' }}>
                  {answerResult.isCorrect ? `+${answerResult.pointsEarned} points` : 'Not this time'}
                </div>
              </div>
            )}
            <div className="card" style={{ padding: '1.25rem', marginBottom: '1rem' }}>
              <div style={{ color: 'var(--text-secondary)', fontSize: '0.8rem', marginBottom: '0.75rem' }}>CORRECT ANSWER{correctOptions.length > 1 ? 'S' : ''}</div>
              {correctOptions.map((o: any) => (
                <div key={o.id} style={{ fontWeight: 700, color: 'var(--accent-green)', fontSize: '1.05rem', marginBottom: '0.25rem' }}>
                  ✓ {o.text}
                </div>
              ))}
            </div>
            <div className="card" style={{ padding: '1.25rem' }}>
              <div style={{ color: 'var(--text-secondary)', fontSize: '0.8rem', marginBottom: '0.75rem' }}>YOUR POSITION</div>
              <div style={{ fontFamily: 'Barlow Condensed', fontSize: '2.5rem', fontWeight: 800, color: 'var(--accent-yellow)' }}>
                #{myRank} — {myScore} pts
              </div>
              <div style={{ color: 'var(--text-secondary)', fontSize: '0.85rem', marginTop: '0.25rem' }}>
                Waiting for host to continue…
              </div>
            </div>
          </div>
        )}

        {/* FINISHED */}
        {phase === 'finished' && (
          <div style={{ textAlign: 'center', maxWidth: 520, width: '100%', animation: 'fadeIn 0.5s ease' }}>
            <div style={{ fontSize: '4rem', marginBottom: '1rem' }}>
              {myRank === 1 ? '🏆' : myRank === 2 ? '🥈' : myRank === 3 ? '🥉' : '🎮'}
            </div>
            <h1 style={{ fontFamily: 'Barlow Condensed', fontSize: '2.5rem', marginBottom: '0.5rem' }}>
              {myRank === 1 ? 'You Won!' : 'Quiz Complete!'}
            </h1>
            <div style={{ fontFamily: 'Barlow Condensed', fontSize: '1.8rem', color: 'var(--accent-yellow)', marginBottom: '2rem' }}>
              #{myRank} · {myScore} pts
            </div>

            <div className="card" style={{ padding: '1.5rem', textAlign: 'left', marginBottom: '1.5rem' }}>
              <div style={{ color: 'var(--text-secondary)', fontSize: '0.8rem', marginBottom: '1rem' }}>FINAL LEADERBOARD</div>
              {leaderboard.map((p: any, i: number) => (
                <div key={p.userId} style={{
                  display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                  padding: '0.65rem 0.75rem', marginBottom: '0.4rem',
                  background: p.userId === user?.id ? 'rgba(245,230,66,0.08)' : 'transparent',
                  borderRadius: 'var(--radius)',
                  border: p.userId === user?.id ? '1px solid rgba(245,230,66,0.2)' : '1px solid transparent',
                }}>
                  <span style={{ fontWeight: 600 }}>
                    {['🥇', '🥈', '🥉'][i] || `#${p.rank}`} {p.name}
                    {p.userId === user?.id && <span style={{ color: 'var(--accent-yellow)', fontSize: '0.8rem' }}> (you)</span>}
                  </span>
                  <span style={{ fontFamily: 'Barlow Condensed', fontSize: '1.3rem', color: 'var(--accent-cyan)' }}>
                    {p.score}
                  </span>
                </div>
              ))}
            </div>

            <div style={{ display: 'flex', gap: '0.75rem', justifyContent: 'center' }}>
              <Link href="/join"><button className="btn-primary">Play Again</button></Link>
              <Link href="/dashboard"><button className="btn-secondary">Dashboard</button></Link>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
