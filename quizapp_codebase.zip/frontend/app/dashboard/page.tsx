'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { api, getUser, clearAuth } from '../lib/socket';

export default function DashboardPage() {
  const router = useRouter();
  const user = getUser();
  const [quizzes, setQuizzes] = useState<any[]>([]);
  const [history, setHistory] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) { router.push('/auth/login'); return; }
    const load = async () => {
      try {
        const [q, h] = await Promise.all([
          user.role === 'ORGANIZER' ? api.get('/api/quizzes?mine=true') : Promise.resolve([]),
          api.get('/api/sessions/history/me'),
        ]);
        setQuizzes(q);
        setHistory(h);
      } catch { /* silent */ }
      finally { setLoading(false); }
    };
    load();
  }, []);

  const handleLogout = () => { clearAuth(); router.push('/'); };

  if (!user) return null;

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg-primary)' }}>
      {/* Navbar */}
      <nav style={{ borderBottom: '1px solid var(--border)', padding: '1rem 0', background: 'var(--bg-secondary)' }}>
        <div className="container" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <Link href="/"><span style={{ fontFamily: 'Barlow Condensed', fontSize: '1.5rem', fontWeight: 800, color: 'var(--accent-yellow)' }}>⚡ QUIZAPP</span></Link>
          <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
            <span style={{ color: 'var(--text-secondary)', fontSize: '0.9rem' }}>
              👋 {user.name}
              <span className="badge badge-cyan" style={{ marginLeft: '0.5rem' }}>{user.role}</span>
            </span>
            <button className="btn-secondary" onClick={handleLogout} style={{ padding: '0.5rem 1rem', fontSize: '0.85rem' }}>Logout</button>
          </div>
        </div>
      </nav>

      <div className="container" style={{ padding: '2.5rem 1.5rem' }}>
        {/* Header row */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem', flexWrap: 'wrap', gap: '1rem' }}>
          <div>
            <h1 style={{ fontFamily: 'Barlow Condensed', fontSize: '2.5rem' }}>Dashboard</h1>
            <p style={{ color: 'var(--text-secondary)', fontSize: '0.9rem' }}>
              {user.role === 'ORGANIZER' ? 'Manage your quizzes and sessions' : 'Your quiz history and scores'}
            </p>
          </div>
          <div style={{ display: 'flex', gap: '0.75rem' }}>
            {user.role === 'ORGANIZER' ? (
              <Link href="/quiz/create"><button className="btn-primary">+ Create Quiz</button></Link>
            ) : (
              <Link href="/join"><button className="btn-cyan">Join a Quiz →</button></Link>
            )}
          </div>
        </div>

        {loading ? (
          <div style={{ textAlign: 'center', padding: '4rem', color: 'var(--text-secondary)' }}>Loading...</div>
        ) : (
          <>
            {/* Organizer: My Quizzes */}
            {user.role === 'ORGANIZER' && (
              <section style={{ marginBottom: '3rem' }}>
                <h2 style={{ fontFamily: 'Barlow Condensed', fontSize: '1.6rem', marginBottom: '1.25rem' }}>My Quizzes</h2>
                {quizzes.length === 0 ? (
                  <div className="card" style={{ textAlign: 'center', padding: '3rem', color: 'var(--text-secondary)' }}>
                    <div style={{ fontSize: '2.5rem', marginBottom: '1rem' }}>🎯</div>
                    <p>No quizzes yet. Create your first one!</p>
                    <Link href="/quiz/create"><button className="btn-primary" style={{ marginTop: '1rem' }}>Create Quiz</button></Link>
                  </div>
                ) : (
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: '1rem' }}>
                    {quizzes.map((q: any) => (
                      <div key={q.id} className="card" style={{ padding: '1.5rem' }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '0.75rem' }}>
                          <span className="badge badge-yellow">{q.category}</span>
                          <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
                            {q._count.questions} questions
                          </span>
                        </div>
                        <h3 style={{ fontFamily: 'Barlow Condensed', fontSize: '1.3rem', marginBottom: '1rem' }}>{q.title}</h3>
                        <div style={{ display: 'flex', gap: '0.75rem', marginTop: 'auto' }}>
                          <Link href={`/quiz/${q.id}/manage`} style={{ flex: 1 }}>
                            <button className="btn-cyan" style={{ width: '100%', padding: '0.65rem' }}>Launch ▶</button>
                          </Link>
                          <Link href={`/quiz/${q.id}/edit`}>
                            <button className="btn-secondary" style={{ padding: '0.65rem 1rem' }}>Edit</button>
                          </Link>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </section>
            )}

            {/* History */}
            <section>
              <h2 style={{ fontFamily: 'Barlow Condensed', fontSize: '1.6rem', marginBottom: '1.25rem' }}>
                {user.role === 'ORGANIZER' ? 'Session History' : 'Quiz History'}
              </h2>
              {history.length === 0 ? (
                <div className="card" style={{ textAlign: 'center', padding: '2.5rem', color: 'var(--text-secondary)' }}>
                  No history yet.
                </div>
              ) : (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                  {history.map((s: any) => (
                    <div key={s.id} className="card" style={{
                      padding: '1.25rem 1.5rem', display: 'flex',
                      justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '0.75rem',
                    }}>
                      <div>
                        <div style={{ fontWeight: 600, marginBottom: '0.2rem' }}>{s.quiz?.title}</div>
                        <div style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>
                          {s.quiz?.category} · {new Date(s.createdAt).toLocaleDateString()}
                        </div>
                      </div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                        <span className={`badge ${s.status === 'FINISHED' ? 'badge-green' : s.status === 'ACTIVE' ? 'badge-pink' : 'badge-cyan'}`}>
                          {s.status}
                        </span>
                        {s.myScore !== undefined && (
                          <span style={{ fontFamily: 'Barlow Condensed', fontSize: '1.4rem', color: 'var(--accent-yellow)', fontWeight: 700 }}>
                            {s.myScore} pts
                          </span>
                        )}
                        {s._count && (
                          <span style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
                            {s._count.participants} players
                          </span>
                        )}
                        {s.status === 'FINISHED' && (
                          <Link href={`/results/${s.id}`}>
                            <button className="btn-secondary" style={{ padding: '0.4rem 0.9rem', fontSize: '0.8rem' }}>
                              Results
                            </button>
                          </Link>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </section>
          </>
        )}
      </div>
    </div>
  );
}
