'use client';
import { useState } from 'react';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { api, saveAuth } from '../../lib/socket';

export default function RegisterPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const defaultRole = searchParams.get('role') || 'PARTICIPANT';

  const [form, setForm] = useState({ email: '', password: '', name: '', role: defaultRole });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const { user, token } = await api.post('/api/auth/register', form);
      saveAuth(token, user);
      router.push('/dashboard');
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{
      minHeight: '100vh', display: 'flex', alignItems: 'center',
      justifyContent: 'center', padding: '2rem',
      background: 'radial-gradient(ellipse at 80% 50%, rgba(156,77,255,0.05) 0%, transparent 60%), var(--bg-primary)',
    }}>
      <div style={{ width: '100%', maxWidth: 460 }}>
        <Link href="/" style={{ display: 'block', textAlign: 'center', marginBottom: '2rem' }}>
          <span style={{ fontFamily: 'Barlow Condensed', fontSize: '2rem', fontWeight: 800, color: 'var(--accent-yellow)' }}>
            ⚡ QUIZAPP
          </span>
        </Link>

        <div className="card" style={{ padding: '2rem' }}>
          <h1 style={{ fontFamily: 'Barlow Condensed', fontSize: '2rem', marginBottom: '0.25rem' }}>Create account</h1>
          <p style={{ color: 'var(--text-secondary)', marginBottom: '1.75rem', fontSize: '0.9rem' }}>Join the platform and start quizzing</p>

          {error && (
            <div style={{
              background: 'rgba(255,61,139,0.1)', border: '1px solid rgba(255,61,139,0.3)',
              borderRadius: 'var(--radius)', padding: '0.75rem 1rem', marginBottom: '1rem',
              color: 'var(--accent-pink)', fontSize: '0.9rem',
            }}>{error}</div>
          )}

          <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            <div>
              <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 600, marginBottom: '0.4rem', color: 'var(--text-secondary)' }}>Full Name</label>
              <input type="text" placeholder="Your name" required
                value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
            </div>
            <div>
              <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 600, marginBottom: '0.4rem', color: 'var(--text-secondary)' }}>Email</label>
              <input type="email" placeholder="you@example.com" required
                value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
            </div>
            <div>
              <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 600, marginBottom: '0.4rem', color: 'var(--text-secondary)' }}>Password</label>
              <input type="password" placeholder="Min. 6 characters" required minLength={6}
                value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />
            </div>
            <div>
              <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 600, marginBottom: '0.4rem', color: 'var(--text-secondary)' }}>I am a...</label>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
                {(['PARTICIPANT', 'ORGANIZER'] as const).map((r) => (
                  <button key={r} type="button"
                    onClick={() => setForm({ ...form, role: r })}
                    style={{
                      padding: '0.75rem', borderRadius: 'var(--radius)',
                      border: `1px solid ${form.role === r ? 'var(--accent-cyan)' : 'var(--border)'}`,
                      background: form.role === r ? 'rgba(0,229,255,0.1)' : 'transparent',
                      color: form.role === r ? 'var(--accent-cyan)' : 'var(--text-secondary)',
                      fontWeight: 600, fontSize: '0.85rem', transition: 'all 0.15s',
                    }}>
                    {r === 'PARTICIPANT' ? '🎮 Participant' : '🎤 Organizer'}
                  </button>
                ))}
              </div>
            </div>
            <button className="btn-primary" type="submit" disabled={loading}
              style={{ marginTop: '0.5rem', width: '100%', opacity: loading ? 0.7 : 1 }}>
              {loading ? 'Creating account...' : 'Create Account →'}
            </button>
          </form>

          <p style={{ textAlign: 'center', marginTop: '1.5rem', color: 'var(--text-secondary)', fontSize: '0.9rem' }}>
            Already have an account?{' '}
            <Link href="/auth/login" style={{ color: 'var(--accent-cyan)', fontWeight: 600 }}>Sign in</Link>
          </p>
        </div>
      </div>
    </div>
  );
}
