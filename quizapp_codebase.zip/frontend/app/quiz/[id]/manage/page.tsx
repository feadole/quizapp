'use client';
import { useEffect, useState, useCallback } from 'react';
import Link from 'next/link';
import { useParams, useRouter } from 'next/navigation';
import { api, getUser, getSocket } from '../../../lib/socket';

type Phase = 'loading' | 'lobby' | 'question' | 'between' | 'finished';

export default function ManagePage() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const user = getUser();

  const [quiz, setQuiz] = useState<any>(null);
  const [session, setSession] = useState<any>(null);
  const [phase, setPhase] = useState<Phase>('loading');
  const [participants, setParticipants] = useState<any[]>([]);
  const [currentQuestion, setCurrentQuestion] = useState<any>(null);
  const [questionIndex, setQuestionIndex] = useState(0);
  const [timeLeft, setTimeLeft] = useState(0);
  const [leaderboard, setLeaderboard] = useState<any[]>([]);
  const [answerProgress, setAnswerProgress] = useState({ answered: 0, total: 0 });
  const [correctOptions, setCorrectOptions] = useState<any[]>([]);
  const [error, setError] = useState('');

  // Load quiz and create session
  useEffect(() => {
    if (!user || user.role !== 'ORGANIZER') { router.push('/dashboard'); return; }
    const init = async () => {
      try {
        const q = await api.get(`/api/quizzes/${id}`);
        setQuiz(q);
        const s = await api.post('/api/sessions', { quizId: id });
        setSession(s);
        setPhase('lobby');
        connectSocket(s.id, s.roomCode);
      } catch (err: any) {
        setError(err.message);
      }
    };
    init();
    return () => { getSocket().disconnect(); };
  }, [id]);

  const connectSocket = useCallback((sessionId: string, roomCode: string) => {
    const socket = getSocket();
    socket.connect();
    socket.emit('join_room', { roomCode, userId: user.id });

    socket.on('participant_joined', ({ participants }: any) => setParticipants(participants));

    socket.on('quiz_started', ({ question, questionIndex: qi }: any) => {
      setCurrentQuestion(question); setQuestionIndex(qi);
      setAnswerProgress({ answered: 0, total: participants.length });
      setPhase('question');
    });

    socket.on('question_shown', ({ question, questionIndex: qi }: any) => {
      setCurrentQuestion(question); setQuestionIndex(qi);
      setCorrectOptions([]);
      setAnswerProgress({ answered: 0, total: participants.length });
      setPhase('question');
    });

    socket.on('timer_tick', ({ timeLeft: t }: any) => setTimeLeft(t));

    socket.on('answer_progress', ({ answered, total }: any) =>
      setAnswerProgress({ answered, total }));

    socket.on('question_ended', ({ correctOptions: co, leaderboard: lb }: any) => {
      setCorrectOptions(co); setLeaderboard(lb); setPhase('between');
    });

    socket.on('quiz_ended', ({ leaderboard: lb }: any) => {
      setLeaderboard(lb); setPhase('finished');
    });

    socket.on('error', ({ message }: any) => setError(message));
  }, [user, participants]);

  const handleStart = () => {
    getSocket().emit('start_quiz', { sessionId: session.id, roomCode: session.roomCode });
  };

  const handleNext = () => {
    getSocket().emit('next_question', { sessionId: session.id, roomCode: session.roomCode });
    setPhase('loading');
  };

  if (phase === 'loading' && !error) return (
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--bg-primary)' }}>
      <div style={{ color: 'var(--text-secondary)' }}>Setting up session...</div>
    </div>
  );

  if (error) return (
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--bg-primary)' }}>
      <div style={{ textAlign: 'center' }}>
        <div style={{ color: 'var(--accent-pink)', marginBottom: '1rem' }}>{error}</div>
        <Link href="/dashboard"><button className="btn-secondary">Back to Dashboard</button></Link>
      </div>
    </div>
  );

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg-primary)' }}>
      <nav style={{ borderBottom: '1px solid var(--border)', padding: '0.75rem 0', background: 'var(--bg-secondary)' }}>
        <div className="container" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span style={{ fontFamily: 'Barlow Condensed', fontSize: '1.4rem', fontWeight: 700 }}>
            {quiz?.title}
          </span>
          {session && (
            <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
              <span style={{ color: 'var(--text-secondary)', fontSize: '0.85rem' }}>Room Code:</span>
              <span style={{
                fontFamily: 'Barlow Condensed', fontSize: '1.8rem', fontWeight: 800,
                color: 'var(--accent-yellow)', letterSpacing: '0.15em',
              }}>{session.roomCode}</span>
            </div>
          )}
          <Link href="/dashboard"><button className="btn-secondary" style={{ padding: '0.5rem 1rem', fontSize: '0.85rem' }}>
            ✕ End Session
          </button></Link>
        </div>
      </nav>

      <div className="container" style={{ padding: '2rem 1.5rem' }}>

        {/* LOBBY */}
        {phase === 'lobby' && (
          <div style={{ maxWidth: 700, margin: '0 auto' }}>
            <div style={{ textAlign: 'center', marginBottom: '2.5rem' }}>
              <div style={{ color: 'var(--text-secondary)', marginBottom: '0.5rem' }}>Players join at quizapp.com/join with code</div>
              <div style={{
                fontFamily: 'Barlow Condensed', fontSize: '4rem', fontWeight: 800,
                color: 'var(--accent-yellow)', letterSpacing: '0.3em',
                animation: 'glow 2s ease-in-out infinite',
              }}>{session?.roomCode}</div>
              <div style={{ color: 'var(--text-secondary)', marginTop: '0.5rem' }}>
                {participants.length} player{participants.length !== 1 ? 's' : ''} connected
              </div>
            </div>

            <div className="card" style={{ marginBottom: '1.5rem', padding: '1.25rem' }}>
              <h3 style={{ fontFamily: 'Barlow Condensed', marginBottom: '1rem', color: 'var(--text-secondary)' }}>
                PARTICIPANTS ({participants.length})
              </h3>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem', minHeight: '3rem' }}>
                {participants.map((p) => (
                  <span key={p.userId} className="badge badge-cyan">{p.name}</span>
                ))}
                {participants.length === 0 && (
                  <span style={{ color: 'var(--text-muted)', fontSize: '0.9rem' }}>Waiting for participants to join…</span>
                )}
              </div>
            </div>

            <button className="btn-primary"
              onClick={handleStart}
              disabled={participants.length === 0}
              style={{ width: '100%', fontSize: '1.1rem', padding: '1.1rem', opacity: participants.length === 0 ? 0.5 : 1 }}>
              {participants.length === 0 ? 'Waiting for players...' : `Start Quiz (${quiz?.questions?.length} questions) →`}
            </button>
          </div>
        )}

        {/* QUESTION DISPLAY */}
        {phase === 'question' && currentQuestion && (
          <div style={{ maxWidth: 800, margin: '0 auto' }}>
            {/* Progress bar */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem' }}>
              <span style={{ color: 'var(--text-secondary)', fontSize: '0.9rem' }}>
                Q{questionIndex + 1} of {currentQuestion.totalQuestions}
              </span>
              <div style={{
                fontFamily: 'Barlow Condensed', fontSize: '3rem', fontWeight: 800,
                color: timeLeft <= 5 ? 'var(--accent-pink)' : 'var(--accent-cyan)',
                transition: 'color 0.3s',
                animation: timeLeft <= 5 ? 'pulse 0.5s ease infinite' : 'none',
              }}>{timeLeft}s</div>
              <span style={{ color: 'var(--text-secondary)', fontSize: '0.9rem' }}>
                {answerProgress.answered}/{answerProgress.total} answered
              </span>
            </div>

            <div className="card" style={{ padding: '2rem', marginBottom: '1.5rem' }}>
              <h2 style={{ fontFamily: 'Barlow Condensed', fontSize: '1.8rem', marginBottom: '1rem' }}>
                {currentQuestion.text}
              </h2>
              {currentQuestion.imageUrl && (
                <img src={currentQuestion.imageUrl} alt="" style={{ maxHeight: 200, borderRadius: 'var(--radius)', objectFit: 'contain', marginBottom: '1rem' }} />
              )}
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
                {currentQuestion.options?.map((opt: any, i: number) => (
                  <div key={opt.id} style={{
                    padding: '1rem', borderRadius: 'var(--radius)', fontSize: '0.95rem', fontWeight: 600,
                    background: ['rgba(245,230,66,0.15)', 'rgba(0,229,255,0.12)', 'rgba(255,61,139,0.12)', 'rgba(0,230,118,0.1)'][i],
                    border: `1px solid ${['rgba(245,230,66,0.3)', 'rgba(0,229,255,0.3)', 'rgba(255,61,139,0.3)', 'rgba(0,230,118,0.25)'][i]}`,
                  }}>{opt.text}</div>
                ))}
              </div>
            </div>

            {/* Progress bar visual */}
            <div style={{ height: 6, background: 'var(--bg-card)', borderRadius: 3, overflow: 'hidden' }}>
              <div style={{
                height: '100%', background: 'var(--accent-cyan)', borderRadius: 3,
                width: `${(answerProgress.answered / Math.max(1, answerProgress.total)) * 100}%`,
                transition: 'width 0.3s ease',
              }} />
            </div>
          </div>
        )}

        {/* BETWEEN QUESTIONS */}
        {phase === 'between' && (
          <div style={{ maxWidth: 700, margin: '0 auto' }}>
            <div className="card" style={{ padding: '2rem', marginBottom: '1.5rem' }}>
              <h2 style={{ fontFamily: 'Barlow Condensed', fontSize: '1.6rem', marginBottom: '1.25rem', color: 'var(--accent-green)' }}>
                ✓ Correct Answers
              </h2>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem', marginBottom: '1.5rem' }}>
                {correctOptions.map((o: any) => (
                  <span key={o.id} className="badge badge-green" style={{ fontSize: '0.95rem', padding: '0.4rem 1rem' }}>{o.text}</span>
                ))}
              </div>

              <h3 style={{ fontFamily: 'Barlow Condensed', fontSize: '1.3rem', marginBottom: '1rem', color: 'var(--text-secondary)' }}>
                TOP 5 LEADERBOARD
              </h3>
              {leaderboard.map((p: any) => (
                <div key={p.userId} style={{
                  display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                  padding: '0.65rem 1rem', marginBottom: '0.5rem',
                  background: p.rank === 1 ? 'rgba(245,230,66,0.08)' : 'var(--bg-secondary)',
                  borderRadius: 'var(--radius)',
                  border: `1px solid ${p.rank === 1 ? 'rgba(245,230,66,0.2)' : 'var(--border)'}`,
                }}>
                  <span style={{ fontWeight: 700, color: p.rank === 1 ? 'var(--accent-yellow)' : 'var(--text-primary)' }}>
                    #{p.rank} {p.name}
                  </span>
                  <span style={{ fontFamily: 'Barlow Condensed', fontSize: '1.3rem', color: 'var(--accent-cyan)' }}>
                    {p.score} pts
                  </span>
                </div>
              ))}
            </div>
            <button className="btn-primary" onClick={handleNext}
              style={{ width: '100%', fontSize: '1.05rem', padding: '1rem' }}>
              Next Question →
            </button>
          </div>
        )}

        {/* FINISHED */}
        {phase === 'finished' && (
          <div style={{ maxWidth: 600, margin: '0 auto', textAlign: 'center' }}>
            <div style={{ fontSize: '4rem', marginBottom: '1rem' }}>🏆</div>
            <h1 style={{ fontFamily: 'Barlow Condensed', fontSize: '3rem', marginBottom: '0.5rem' }}>Quiz Complete!</h1>
            <p style={{ color: 'var(--text-secondary)', marginBottom: '2.5rem' }}>Final standings for <strong>{quiz?.title}</strong></p>

            <div className="card" style={{ padding: '1.5rem', marginBottom: '1.5rem', textAlign: 'left' }}>
              {leaderboard.map((p: any, i: number) => (
                <div key={p.userId} style={{
                  display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                  padding: '0.85rem 1rem', marginBottom: i < leaderboard.length - 1 ? '0.5rem' : 0,
                  background: i === 0 ? 'rgba(245,230,66,0.1)' : i === 1 ? 'rgba(200,200,200,0.05)' : i === 2 ? 'rgba(180,120,60,0.08)' : 'transparent',
                  borderRadius: 'var(--radius)',
                  border: i < 3 ? `1px solid ${['rgba(245,230,66,0.25)', 'rgba(200,200,200,0.15)', 'rgba(180,120,60,0.2)'][i]}` : 'none',
                }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                    <span style={{ fontFamily: 'Barlow Condensed', fontSize: '1.5rem', fontWeight: 800,
                      color: ['var(--accent-yellow)', '#bbb', '#c87941', 'var(--text-secondary)'][Math.min(i, 3)] }}>
                      {['🥇', '🥈', '🥉'][i] || `#${p.rank}`}
                    </span>
                    <span style={{ fontWeight: 600 }}>{p.name}</span>
                  </div>
                  <span style={{ fontFamily: 'Barlow Condensed', fontSize: '1.5rem', color: 'var(--accent-cyan)' }}>
                    {p.score} pts
                  </span>
                </div>
              ))}
            </div>

            <Link href="/dashboard">
              <button className="btn-primary" style={{ padding: '0.9rem 2rem', fontSize: '1rem' }}>
                Back to Dashboard
              </button>
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}
