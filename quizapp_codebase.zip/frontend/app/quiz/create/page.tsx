'use client';
import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { api, getUser } from '../../lib/socket';

interface Option { text: string; isCorrect: boolean; }
interface Question {
  text: string; imageUrl: string; type: 'SINGLE' | 'MULTIPLE';
  timeLimit: number; points: number; options: Option[];
}

const defaultOption = (): Option => ({ text: '', isCorrect: false });
const defaultQuestion = (): Question => ({
  text: '', imageUrl: '', type: 'SINGLE', timeLimit: 30, points: 100,
  options: [defaultOption(), defaultOption(), defaultOption(), defaultOption()],
});

export default function CreateQuizPage() {
  const router = useRouter();
  const user = getUser();
  const [meta, setMeta] = useState({ title: '', description: '', category: 'General', isPublic: true });
  const [questions, setQuestions] = useState<Question[]>([defaultQuestion()]);
  const [activeQ, setActiveQ] = useState(0);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const q = questions[activeQ];

  const updateQ = (patch: Partial<Question>) => {
    setQuestions((prev) => prev.map((q, i) => i === activeQ ? { ...q, ...patch } : q));
  };

  const updateOption = (optIdx: number, patch: Partial<Option>) => {
    updateQ({
      options: q.options.map((o, i) => i === optIdx ? { ...o, ...patch } : o),
    });
  };

  const toggleCorrect = (optIdx: number) => {
    if (q.type === 'SINGLE') {
      updateQ({ options: q.options.map((o, i) => ({ ...o, isCorrect: i === optIdx })) });
    } else {
      updateOption(optIdx, { isCorrect: !q.options[optIdx].isCorrect });
    }
  };

  const handleSave = async () => {
    if (!meta.title.trim()) { setError('Quiz title is required'); return; }
    for (let i = 0; i < questions.length; i++) {
      const q = questions[i];
      if (!q.text.trim()) { setError(`Question ${i + 1} has no text`); setActiveQ(i); return; }
      if (q.options.filter((o) => o.text.trim()).length < 2) {
        setError(`Question ${i + 1} needs at least 2 options`); setActiveQ(i); return;
      }
      if (!q.options.some((o) => o.isCorrect)) {
        setError(`Question ${i + 1} needs at least 1 correct answer`); setActiveQ(i); return;
      }
    }
    setError(''); setSaving(true);
    try {
      const payload = {
        ...meta,
        questions: questions.map((q) => ({
          ...q,
          options: q.options.filter((o) => o.text.trim()),
        })),
      };
      const quiz = await api.post('/api/quizzes', payload);
      router.push(`/quiz/${quiz.id}/manage`);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg-primary)' }}>
      <nav style={{ borderBottom: '1px solid var(--border)', padding: '1rem 0', background: 'var(--bg-secondary)' }}>
        <div className="container" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <Link href="/dashboard"><button className="btn-secondary" style={{ padding: '0.5rem 1rem' }}>← Dashboard</button></Link>
          <h1 style={{ fontFamily: 'Barlow Condensed', fontSize: '1.5rem' }}>Create Quiz</h1>
          <button className="btn-primary" onClick={handleSave} disabled={saving}>
            {saving ? 'Saving...' : 'Save & Launch →'}
          </button>
        </div>
      </nav>

      <div className="container" style={{ padding: '2rem 1.5rem', display: 'grid', gridTemplateColumns: '280px 1fr', gap: '2rem' }}>
        {/* Left panel: quiz meta + question list */}
        <div>
          <div className="card" style={{ marginBottom: '1.5rem' }}>
            <h3 style={{ fontFamily: 'Barlow Condensed', fontSize: '1.1rem', marginBottom: '1rem', color: 'var(--text-secondary)' }}>
              QUIZ SETTINGS
            </h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
              <input placeholder="Quiz title *" value={meta.title} onChange={(e) => setMeta({ ...meta, title: e.target.value })} />
              <input placeholder="Description (optional)" value={meta.description} onChange={(e) => setMeta({ ...meta, description: e.target.value })} />
              <select value={meta.category} onChange={(e) => setMeta({ ...meta, category: e.target.value })}>
                {['General', 'Science', 'History', 'Geography', 'Sports', 'Technology', 'Pop Culture', 'Literature'].map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="card">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
              <h3 style={{ fontFamily: 'Barlow Condensed', fontSize: '1.1rem', color: 'var(--text-secondary)' }}>QUESTIONS</h3>
              <button className="btn-primary" style={{ padding: '0.4rem 0.9rem', fontSize: '0.8rem' }}
                onClick={() => { setQuestions([...questions, defaultQuestion()]); setActiveQ(questions.length); }}>
                + Add
              </button>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
              {questions.map((q, i) => (
                <div key={i} onClick={() => setActiveQ(i)}
                  style={{
                    padding: '0.75rem', borderRadius: 'var(--radius)', cursor: 'pointer',
                    border: `1px solid ${activeQ === i ? 'var(--accent-cyan)' : 'var(--border)'}`,
                    background: activeQ === i ? 'rgba(0,229,255,0.05)' : 'transparent',
                    display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                  }}>
                  <span style={{ fontSize: '0.85rem', color: activeQ === i ? 'var(--accent-cyan)' : 'var(--text-primary)' }}>
                    Q{i + 1}: {q.text ? q.text.substring(0, 30) + (q.text.length > 30 ? '…' : '') : '(empty)'}
                  </span>
                  {questions.length > 1 && (
                    <button onClick={(e) => {
                      e.stopPropagation();
                      setQuestions(questions.filter((_, j) => j !== i));
                      setActiveQ(Math.max(0, activeQ - 1));
                    }} style={{ background: 'none', color: 'var(--text-muted)', fontSize: '1rem', padding: '0 4px' }}>×</button>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right panel: question editor */}
        <div className="card" style={{ padding: '2rem' }}>
          {error && (
            <div style={{
              background: 'rgba(255,61,139,0.1)', border: '1px solid rgba(255,61,139,0.3)',
              borderRadius: 'var(--radius)', padding: '0.75rem 1rem', marginBottom: '1.5rem',
              color: 'var(--accent-pink)', fontSize: '0.9rem',
            }}>{error}</div>
          )}

          <h2 style={{ fontFamily: 'Barlow Condensed', fontSize: '1.6rem', marginBottom: '1.5rem' }}>
            Question {activeQ + 1}
          </h2>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
            <div>
              <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 600, marginBottom: '0.4rem', color: 'var(--text-secondary)' }}>
                Question Text *
              </label>
              <textarea rows={3} placeholder="Type your question here..."
                value={q.text} onChange={(e) => updateQ({ text: e.target.value })}
                style={{ resize: 'vertical' }} />
            </div>

            <div>
              <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 600, marginBottom: '0.4rem', color: 'var(--text-secondary)' }}>
                Image URL (optional)
              </label>
              <input placeholder="https://example.com/image.jpg" value={q.imageUrl}
                onChange={(e) => updateQ({ imageUrl: e.target.value })} />
              {q.imageUrl && (
                <img src={q.imageUrl} alt="preview" style={{ marginTop: '0.5rem', maxHeight: 140, borderRadius: 'var(--radius)', objectFit: 'cover' }}
                  onError={(e) => (e.currentTarget.style.display = 'none')} />
              )}
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '0.75rem' }}>
              <div>
                <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 600, marginBottom: '0.4rem', color: 'var(--text-secondary)' }}>Type</label>
                <select value={q.type} onChange={(e) => updateQ({ type: e.target.value as 'SINGLE' | 'MULTIPLE' })}>
                  <option value="SINGLE">Single Choice</option>
                  <option value="MULTIPLE">Multiple Choice</option>
                </select>
              </div>
              <div>
                <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 600, marginBottom: '0.4rem', color: 'var(--text-secondary)' }}>Time (sec)</label>
                <select value={q.timeLimit} onChange={(e) => updateQ({ timeLimit: Number(e.target.value) })}>
                  {[10, 15, 20, 30, 45, 60].map((t) => <option key={t} value={t}>{t}s</option>)}
                </select>
              </div>
              <div>
                <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 600, marginBottom: '0.4rem', color: 'var(--text-secondary)' }}>Points</label>
                <select value={q.points} onChange={(e) => updateQ({ points: Number(e.target.value) })}>
                  {[50, 100, 200, 500].map((p) => <option key={p} value={p}>{p}</option>)}
                </select>
              </div>
            </div>

            <div>
              <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 600, marginBottom: '0.75rem', color: 'var(--text-secondary)' }}>
                Answer Options — click to mark correct {q.type === 'MULTIPLE' ? '(multiple allowed)' : '(one only)'}
              </label>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
                {q.options.map((opt, i) => (
                  <div key={i} style={{
                    display: 'flex', alignItems: 'center', gap: '0.5rem',
                    border: `2px solid ${opt.isCorrect ? 'var(--accent-green)' : 'var(--border)'}`,
                    borderRadius: 'var(--radius)', padding: '0.5rem 0.75rem',
                    background: opt.isCorrect ? 'rgba(0,230,118,0.08)' : 'transparent',
                    transition: 'all 0.15s',
                  }}>
                    <button onClick={() => toggleCorrect(i)}
                      style={{
                        width: 22, height: 22, borderRadius: q.type === 'MULTIPLE' ? 4 : '50%',
                        border: `2px solid ${opt.isCorrect ? 'var(--accent-green)' : 'var(--text-muted)'}`,
                        background: opt.isCorrect ? 'var(--accent-green)' : 'transparent',
                        flexShrink: 0, transition: 'all 0.15s',
                        display: 'flex', alignItems: 'center', justifyContent: 'center',
                        fontSize: '0.7rem', color: '#0a0a12',
                      }}>
                      {opt.isCorrect && '✓'}
                    </button>
                    <input placeholder={`Option ${i + 1}`} value={opt.text}
                      onChange={(e) => updateOption(i, { text: e.target.value })}
                      style={{ border: 'none', background: 'transparent', padding: '0.25rem 0', flex: 1 }} />
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
