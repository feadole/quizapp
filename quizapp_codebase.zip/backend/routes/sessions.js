const express = require('express');
const router = express.Router();
const { PrismaClient } = require('@prisma/client');
const { authenticate, requireOrganizer } = require('../middleware/auth');

const prisma = new PrismaClient();

function generateRoomCode() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = '';
  for (let i = 0; i < 6; i++) code += chars[Math.floor(Math.random() * chars.length)];
  return code;
}

// POST /api/sessions  - organizer creates a session
router.post('/', authenticate, requireOrganizer, async (req, res) => {
  try {
    const { quizId } = req.body;
    const quiz = await prisma.quiz.findUnique({ where: { id: quizId } });
    if (!quiz) return res.status(404).json({ error: 'Quiz not found' });
    if (quiz.organizerId !== req.user.id) {
      return res.status(403).json({ error: 'Not your quiz' });
    }

    let roomCode, exists;
    do {
      roomCode = generateRoomCode();
      exists = await prisma.session.findUnique({ where: { roomCode } });
    } while (exists);

    const session = await prisma.session.create({
      data: { quizId, roomCode, status: 'WAITING' },
      include: { quiz: { select: { title: true, id: true } } },
    });
    res.status(201).json(session);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to create session' });
  }
});

// GET /api/sessions/room/:code  - participant looks up a room
router.get('/room/:code', async (req, res) => {
  try {
    const session = await prisma.session.findUnique({
      where: { roomCode: req.params.code.toUpperCase() },
      include: {
        quiz: { select: { title: true, category: true, description: true } },
        _count: { select: { participants: true } },
      },
    });
    if (!session) return res.status(404).json({ error: 'Room not found' });
    if (session.status === 'FINISHED') {
      return res.status(410).json({ error: 'This quiz has already ended' });
    }
    res.json(session);
  } catch {
    res.status(500).json({ error: 'Failed to find room' });
  }
});

// GET /api/sessions/:id/leaderboard
router.get('/:id/leaderboard', async (req, res) => {
  try {
    const participants = await prisma.sessionParticipant.findMany({
      where: { sessionId: req.params.id },
      include: { user: { select: { id: true, name: true } } },
      orderBy: { score: 'desc' },
    });
    const leaderboard = participants.map((p, i) => ({
      rank: i + 1,
      userId: p.userId,
      name: p.user.name,
      score: p.score,
    }));
    res.json(leaderboard);
  } catch {
    res.status(500).json({ error: 'Failed to fetch leaderboard' });
  }
});

// GET /api/sessions/history  - user's session history
router.get('/history/me', authenticate, async (req, res) => {
  try {
    const isOrganizer = req.user.role === 'ORGANIZER';
    let data;

    if (isOrganizer) {
      data = await prisma.session.findMany({
        where: { quiz: { organizerId: req.user.id } },
        include: {
          quiz: { select: { title: true, category: true } },
          _count: { select: { participants: true } },
        },
        orderBy: { createdAt: 'desc' },
      });
    } else {
      const participations = await prisma.sessionParticipant.findMany({
        where: { userId: req.user.id },
        include: {
          session: {
            include: {
              quiz: { select: { title: true, category: true } },
              _count: { select: { participants: true } },
            },
          },
        },
        orderBy: { joinedAt: 'desc' },
      });
      data = participations.map((p) => ({
        ...p.session,
        myScore: p.score,
      }));
    }
    res.json(data);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch history' });
  }
});

module.exports = router;
