const express = require('express');
const router = express.Router();
const { PrismaClient } = require('@prisma/client');
const { authenticate, requireOrganizer } = require('../middleware/auth');

const prisma = new PrismaClient();

// GET /api/quizzes  - list public quizzes or organizer's quizzes
router.get('/', authenticate, async (req, res) => {
  try {
    const { mine } = req.query;
    const where = mine === 'true'
      ? { organizerId: req.user.id }
      : { isPublic: true };

    const quizzes = await prisma.quiz.findMany({
      where,
      include: {
        organizer: { select: { id: true, name: true } },
        _count: { select: { questions: true, sessions: true } },
      },
      orderBy: { createdAt: 'desc' },
    });
    res.json(quizzes);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch quizzes' });
  }
});

// GET /api/quizzes/:id
router.get('/:id', authenticate, async (req, res) => {
  try {
    const quiz = await prisma.quiz.findUnique({
      where: { id: req.params.id },
      include: {
        organizer: { select: { id: true, name: true } },
        questions: {
          include: { options: { orderBy: { order: 'asc' } } },
          orderBy: { order: 'asc' },
        },
      },
    });
    if (!quiz) return res.status(404).json({ error: 'Quiz not found' });
    res.json(quiz);
  } catch {
    res.status(500).json({ error: 'Failed to fetch quiz' });
  }
});

// POST /api/quizzes  - create quiz with questions
router.post('/', authenticate, requireOrganizer, async (req, res) => {
  try {
    const { title, description, category, isPublic, questions } = req.body;
    if (!title) return res.status(400).json({ error: 'Title is required' });

    const quiz = await prisma.quiz.create({
      data: {
        title,
        description,
        category: category || 'General',
        isPublic: isPublic !== false,
        organizerId: req.user.id,
        questions: {
          create: (questions || []).map((q, i) => ({
            text: q.text,
            imageUrl: q.imageUrl || null,
            type: q.type || 'SINGLE',
            timeLimit: q.timeLimit || 30,
            points: q.points || 100,
            order: i,
            options: {
              create: (q.options || []).map((opt, j) => ({
                text: opt.text,
                isCorrect: opt.isCorrect,
                order: j,
              })),
            },
          })),
        },
      },
      include: {
        questions: { include: { options: true }, orderBy: { order: 'asc' } },
      },
    });
    res.status(201).json(quiz);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to create quiz' });
  }
});

// PUT /api/quizzes/:id
router.put('/:id', authenticate, requireOrganizer, async (req, res) => {
  try {
    const quiz = await prisma.quiz.findUnique({ where: { id: req.params.id } });
    if (!quiz) return res.status(404).json({ error: 'Quiz not found' });
    if (quiz.organizerId !== req.user.id) {
      return res.status(403).json({ error: 'Not your quiz' });
    }
    const { title, description, category, isPublic } = req.body;
    const updated = await prisma.quiz.update({
      where: { id: req.params.id },
      data: { title, description, category, isPublic },
    });
    res.json(updated);
  } catch {
    res.status(500).json({ error: 'Failed to update quiz' });
  }
});

// DELETE /api/quizzes/:id
router.delete('/:id', authenticate, requireOrganizer, async (req, res) => {
  try {
    const quiz = await prisma.quiz.findUnique({ where: { id: req.params.id } });
    if (!quiz) return res.status(404).json({ error: 'Quiz not found' });
    if (quiz.organizerId !== req.user.id) {
      return res.status(403).json({ error: 'Not your quiz' });
    }
    await prisma.quiz.delete({ where: { id: req.params.id } });
    res.json({ message: 'Quiz deleted' });
  } catch {
    res.status(500).json({ error: 'Failed to delete quiz' });
  }
});

module.exports = router;
