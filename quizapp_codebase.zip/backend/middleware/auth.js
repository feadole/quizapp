const jwt = require('jsonwebtoken');

const authenticate = (req, res, next) => {
  const authHeader = req.headers.authorization;
  if (!authHeader?.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'No token provided' });
  }
  const token = authHeader.split(' ')[1];
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'quizapp_secret');
    req.user = decoded;
    next();
  } catch {
    return res.status(401).json({ error: 'Invalid or expired token' });
  }
};

const requireOrganizer = (req, res, next) => {
  if (req.user?.role !== 'ORGANIZER') {
    return res.status(403).json({ error: 'Organizer access required' });
  }
  next();
};

module.exports = { authenticate, requireOrganizer };
