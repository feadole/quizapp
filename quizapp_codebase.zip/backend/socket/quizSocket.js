const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

// Track active timers and question start times
const activeTimers = new Map();    // sessionId -> intervalId
const questionStartTimes = new Map(); // `${sessionId}:${questionIndex}` -> Date

function clearSessionTimer(sessionId) {
  const timer = activeTimers.get(sessionId);
  if (timer) {
    clearInterval(timer);
    activeTimers.delete(sessionId);
  }
}

async function getQuestion(sessionId, index) {
  const session = await prisma.session.findUnique({
    where: { id: sessionId },
    include: {
      quiz: {
        include: {
          questions: {
            include: { options: { orderBy: { order: 'asc' } } },
            orderBy: { order: 'asc' },
          },
        },
      },
    },
  });
  if (!session) return null;
  const q = session.quiz.questions[index];
  if (!q) return null;
  return {
    ...q,
    // Strip isCorrect from options before sending to participants
    options: q.options.map(({ id, text, order }) => ({ id, text, order })),
    totalQuestions: session.quiz.questions.length,
  };
}

async function buildLeaderboard(sessionId) {
  const participants = await prisma.sessionParticipant.findMany({
    where: { sessionId },
    include: { user: { select: { id: true, name: true } } },
    orderBy: { score: 'desc' },
  });
  return participants.map((p, i) => ({
    rank: i + 1,
    userId: p.userId,
    name: p.user.name,
    score: p.score,
  }));
}

async function scoreAnswer(participantId, questionId, selectedOptionIds, timeToAnswer, timeLimit) {
  // Check if already answered
  const existing = await prisma.answer.findUnique({
    where: { participantId_questionId: { participantId, questionId } },
  });
  if (existing) return { alreadyAnswered: true, pointsEarned: 0 };

  const question = await prisma.question.findUnique({
    where: { id: questionId },
    include: { options: true },
  });
  if (!question) return { error: true };

  const correctIds = question.options.filter((o) => o.isCorrect).map((o) => o.id).sort();
  const selectedSorted = [...selectedOptionIds].sort();

  let isCorrect = false;
  if (question.type === 'SINGLE') {
    isCorrect = selectedSorted.length === 1 && correctIds.includes(selectedSorted[0]);
  } else {
    isCorrect =
      correctIds.length === selectedSorted.length &&
      correctIds.every((id) => selectedSorted.includes(id));
  }

  // Time bonus: max points at 0s, min 30% at timeLimit
  let pointsEarned = 0;
  if (isCorrect) {
    const fraction = Math.max(0, 1 - timeToAnswer / (timeLimit * 1000));
    const timeFactor = 0.3 + 0.7 * fraction;
    pointsEarned = Math.round(question.points * timeFactor);
  }

  await prisma.answer.create({
    data: {
      participantId,
      questionId,
      selectedOptions: selectedOptionIds,
      isCorrect,
      pointsEarned,
      timeToAnswer,
    },
  });

  if (pointsEarned > 0) {
    await prisma.sessionParticipant.update({
      where: { id: participantId },
      data: { score: { increment: pointsEarned } },
    });
  }

  return { isCorrect, pointsEarned, correctIds };
}

function startQuestionTimer(io, roomCode, sessionId, question, questionIndex) {
  clearSessionTimer(sessionId);
  const key = `${sessionId}:${questionIndex}`;
  questionStartTimes.set(key, Date.now());

  let timeLeft = question.timeLimit;
  io.to(roomCode).emit('timer_tick', { timeLeft });

  const interval = setInterval(async () => {
    timeLeft--;
    io.to(roomCode).emit('timer_tick', { timeLeft });

    if (timeLeft <= 0) {
      clearInterval(interval);
      activeTimers.delete(sessionId);
      questionStartTimes.delete(key);

      // Reveal correct answers
      const fullQuestion = await prisma.question.findUnique({
        where: { id: question.id },
        include: { options: true },
      });
      const correctOptions = fullQuestion.options.filter((o) => o.isCorrect);

      const scores = await buildLeaderboard(sessionId);
      io.to(roomCode).emit('question_ended', {
        questionId: question.id,
        correctOptions,
        leaderboard: scores.slice(0, 5),
      });
    }
  }, 1000);

  activeTimers.set(sessionId, interval);
}

function registerQuizSocket(io) {
  io.on('connection', (socket) => {
    console.log(`Socket connected: ${socket.id}`);

    // ── JOIN ROOM ─────────────────────────────────────────────
    socket.on('join_room', async ({ roomCode, userId }) => {
      try {
        const session = await prisma.session.findUnique({
          where: { roomCode },
          include: {
            quiz: { select: { title: true, id: true } },
            participants: {
              include: { user: { select: { id: true, name: true } } },
            },
          },
        });

        if (!session) {
          return socket.emit('error', { message: 'Room not found' });
        }
        if (session.status === 'FINISHED') {
          return socket.emit('error', { message: 'Quiz already ended' });
        }

        socket.join(roomCode);
        socket.data.roomCode = roomCode;
        socket.data.userId = userId;
        socket.data.sessionId = session.id;

        // Upsert participant
        await prisma.sessionParticipant.upsert({
          where: { sessionId_userId: { sessionId: session.id, userId } },
          create: { sessionId: session.id, userId },
          update: {},
        });

        const updatedSession = await prisma.session.findUnique({
          where: { id: session.id },
          include: {
            participants: {
              include: { user: { select: { id: true, name: true } } },
            },
          },
        });
        const participants = updatedSession.participants.map((p) => ({
          userId: p.userId,
          name: p.user.name,
          score: p.score,
        }));

        socket.emit('room_joined', {
          sessionId: session.id,
          quizTitle: session.quiz.title,
          status: session.status,
          participants,
        });

        socket.to(roomCode).emit('participant_joined', {
          userId,
          participants,
        });
      } catch (err) {
        console.error('join_room error:', err);
        socket.emit('error', { message: 'Failed to join room' });
      }
    });

    // ── START QUIZ ────────────────────────────────────────────
    socket.on('start_quiz', async ({ sessionId, roomCode }) => {
      try {
        const session = await prisma.session.findUnique({ where: { id: sessionId } });
        if (!session || session.status !== 'WAITING') {
          return socket.emit('error', { message: 'Cannot start quiz' });
        }

        await prisma.session.update({
          where: { id: sessionId },
          data: { status: 'ACTIVE', currentQ: 0, startedAt: new Date() },
        });

        const question = await getQuestion(sessionId, 0);
        if (!question) {
          return socket.emit('error', { message: 'No questions in this quiz' });
        }

        io.to(roomCode).emit('quiz_started', {
          question,
          questionIndex: 0,
        });

        startQuestionTimer(io, roomCode, sessionId, question, 0);
      } catch (err) {
        console.error('start_quiz error:', err);
        socket.emit('error', { message: 'Failed to start quiz' });
      }
    });

    // ── SUBMIT ANSWER ─────────────────────────────────────────
    socket.on('submit_answer', async ({ participantId, questionId, selectedOptions, sessionId, questionIndex }) => {
      try {
        const key = `${sessionId}:${questionIndex}`;
        const startTime = questionStartTimes.get(key) || Date.now();
        const timeToAnswer = Date.now() - startTime;

        const session = await prisma.session.findUnique({ where: { id: sessionId } });
        const question = await prisma.question.findUnique({ where: { id: questionId } });

        const result = await scoreAnswer(
          participantId,
          questionId,
          selectedOptions,
          timeToAnswer,
          question.timeLimit,
        );

        if (result.alreadyAnswered) {
          return socket.emit('already_answered');
        }

        socket.emit('answer_result', {
          isCorrect: result.isCorrect,
          pointsEarned: result.pointsEarned,
        });

        // Count how many have answered
        const answered = await prisma.answer.count({
          where: {
            questionId,
            participant: { sessionId },
          },
        });
        const total = await prisma.sessionParticipant.count({ where: { sessionId } });

        io.to(socket.data.roomCode).emit('answer_progress', {
          answered,
          total,
          questionId,
        });

        // Auto-advance if everyone answered
        if (answered >= total) {
          clearSessionTimer(sessionId);
          const fullQuestion = await prisma.question.findUnique({
            where: { id: questionId },
            include: { options: true },
          });
          const correctOptions = fullQuestion.options.filter((o) => o.isCorrect);
          const scores = await buildLeaderboard(sessionId);
          io.to(socket.data.roomCode).emit('question_ended', {
            questionId,
            correctOptions,
            leaderboard: scores.slice(0, 5),
          });
        }
      } catch (err) {
        console.error('submit_answer error:', err);
        socket.emit('error', { message: 'Failed to submit answer' });
      }
    });

    // ── NEXT QUESTION ─────────────────────────────────────────
    socket.on('next_question', async ({ sessionId, roomCode }) => {
      try {
        const session = await prisma.session.findUnique({ where: { id: sessionId } });
        if (!session) return;

        const nextIndex = session.currentQ + 1;
        const question = await getQuestion(sessionId, nextIndex);

        if (!question) {
          // End quiz
          await prisma.session.update({
            where: { id: sessionId },
            data: { status: 'FINISHED', endedAt: new Date() },
          });
          const leaderboard = await buildLeaderboard(sessionId);
          io.to(roomCode).emit('quiz_ended', { leaderboard });
          return;
        }

        await prisma.session.update({
          where: { id: sessionId },
          data: { currentQ: nextIndex },
        });

        io.to(roomCode).emit('question_shown', {
          question,
          questionIndex: nextIndex,
        });

        startQuestionTimer(io, roomCode, sessionId, question, nextIndex);
      } catch (err) {
        console.error('next_question error:', err);
        socket.emit('error', { message: 'Failed to advance question' });
      }
    });

    // ── DISCONNECT ────────────────────────────────────────────
    socket.on('disconnect', async () => {
      const { roomCode, userId } = socket.data;
      if (roomCode && userId) {
        socket.to(roomCode).emit('participant_left', { userId });
      }
      console.log(`Socket disconnected: ${socket.id}`);
    });
  });
}

module.exports = { registerQuizSocket };
